﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labbook2_4
{
    class ProductDemo
  
    {
        static void Main(string[] args)
        {

            int ID , quantity;
            double price;
            string name;

            Console.WriteLine("product details are:");

            Console.WriteLine("enter the product id:");
            ID = Convert.ToInt32(Console.ReadLine());


            Console.WriteLine("enter the product name:");
            name =Console.ReadLine();

            Console.WriteLine("enter the quantity:");
            quantity =Convert.ToInt32( Console.ReadLine());

            Console.WriteLine("enter the price:");
            price = Convert.ToDouble(Console.ReadLine());


            object obj = ID; //boxing
            object obj1 = name;
            object obj2 = price;
            object obj3 = quantity;

            int i = (int)obj; //unboxing
            string j = (string)obj1;
            double k = (double)obj2;
            int l = (int)obj3;

            double m = k * l;

            Console.WriteLine($"product details are:");

            Console.WriteLine("product id:" + obj);
            Console.WriteLine("product name:" + obj1);
            Console.WriteLine("price:" + obj2);
            Console.WriteLine("quantity:" + obj3);

            Console.WriteLine("Amt payable:" + m);

            Console.ReadKey();


















        }
    }
}
