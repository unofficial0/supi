﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Car;

namespace Labbook3_3
{
    class Program
    {
        static void Main(string[] args)
        {

            Car.car[] c = new Car.car[15];
            int count = 0;
            int UserChoice;
            int cid;
            do
            {
                Console.WriteLine("-----Car Menu------");
                Console.WriteLine("Enter 1 for AddCar 2 for Delete Car 3 for search Car 4 for Update car 5 for DisplayCar");
                Console.WriteLine("Eter UserChoice");
                UserChoice = Convert.ToInt32(Console.ReadLine());
                switch (UserChoice)
                {
                    case 1:
                        c[count] = new Car.car();
                        c[count].AddCar();
                        count++;
                        break;
                    case 2:
                        Console.WriteLine("enter car id");
                        int a = Convert.ToInt32(Console.ReadLine());
                        for (int i = 0; i < count; i++)
                        {
                            if (a == c[i].id)
                                c[i].Delete();
                        }
                        
                        Console.WriteLine("Data deleted successfully ");
                        break;
                    case 3:
                        Console.WriteLine("enter car id");
                        cid = Convert.ToInt16(Console.ReadLine());
                        for (int i = 0; i < count; i++)
                        {
                            if (cid == c[i].id)
                                c[i].Display();
                        }
                        break;
                    case 4:
                        Console.WriteLine("enter car id");
                       cid= Convert.ToInt32(Console.ReadLine());
                        for (int i = 0; i < count; i++)
                        {
                            if (cid == c[i].id)
                                c[i].Update();
                        }
                       
                        Console.WriteLine("Data updated successfully");
                        break;
                    case 5:
                        for (int i = 0; i < count; i++)
                        {
                            c[i].Display();
                        }
                        break;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;

                }
            } while (UserChoice != 0);
            Console.ReadLine();
        }
    }
}
